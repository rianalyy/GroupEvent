import 'package:flutter/material.dart';
import '../../views/welcome/welcome_view.dart';
import '../../views/auth/login_view.dart';
import '../../views/auth/register_view.dart';
import '../../views/home/home_view.dart';

class AppRoutes {
  static const welcome = '/';
  static const login = '/login';
  static const register = '/register';
  static const home = '/home';

  static Map<String, WidgetBuilder> routes = {
    welcome: (_) => const WelcomeView(),
    login: (_) => const LoginView(),
    register: (_) => const RegisterView(),
    //home: (_) => const HomeView(),
  };
}