class EventModel {
  final String title;
  final String date;
  final int participants;
  final double budget;

  EventModel({
    required this.title,
    required this.date,
    required this.participants,
    required this.budget,
  });
}