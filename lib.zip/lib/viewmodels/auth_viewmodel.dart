import 'package:flutter/material.dart';
import '../services/database_service.dart';
import '../models/user_model.dart';

class AuthViewModel extends ChangeNotifier {
  String email = '';
  String password = '';

  void setEmail(String value) {
    email = value;
    notifyListeners();
  }

  void setPassword(String value) {
    password = value;
    notifyListeners();
  }

  Future<void> register(BuildContext context) async {
    if (email.isEmpty || password.isEmpty) return;

    await DatabaseService.insertUser(
      UserModel(email: email, password: password),
    );

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("Inscription réussie"),
        backgroundColor: Colors.green,
      ),
    );
  }

  Future<bool> login(BuildContext context) async {
    final user = await DatabaseService.login(email, password);

    if (user != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Connexion réussie")),
      );
      return true;
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Identifiants incorrects")),
      );
      return false;
    }
  }
}