import 'package:flutter/material.dart';
import '../models/event_model.dart';

class EventViewModel extends ChangeNotifier {
  final List<EventModel> events = [
    EventModel(
      title: "Soirée BBQ",
      date: "12 Avril",
      participants: 8,
      budget: 200000,
    ),
  ];
}