import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../viewmodels/event_viewmodel.dart';

class HomeView extends StatelessWidget {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => EventViewModel(),
      child: Scaffold(
        body: Container(
          width: double.infinity,
          height: double.infinity,
          color: const Color(0xFF4C0A7A),

          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Consumer<EventViewModel>(
                builder: (context, vm, child) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Bonjour ",
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 16,
                        ),
                      ),

                      const SizedBox(height: 5),

                      const Text(
                        "Mes événements",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      const SizedBox(height: 20),

                      Expanded(
                        child: vm.events.isEmpty
                            ? const Center(
                                child: Text(
                                  "Aucun événement pour le moment",
                                  style: TextStyle(
                                    color: Colors.white70,
                                  ),
                                ),
                              )
                            : ListView.builder(
                                itemCount: vm.events.length,
                                itemBuilder: (context, index) {
                                  final event = vm.events[index];

                                  return Container(
                                    margin:
                                        const EdgeInsets.only(bottom: 15),
                                    padding: const EdgeInsets.all(16),
                                    decoration: BoxDecoration(
                                      color:
                                          Colors.white.withOpacity(0.1),
                                      borderRadius:
                                          BorderRadius.circular(16),
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          event.title,
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 18,
                                            fontWeight:
                                                FontWeight.bold,
                                          ),
                                        ),

                                        const SizedBox(height: 8),

                                        Row(
                                          children: [
                                            const Icon(Icons.calendar_today,
                                                size: 16,
                                                color: Colors.white70),
                                            const SizedBox(width: 5),
                                            Text(
                                              event.date,
                                              style: const TextStyle(
                                                  color:
                                                      Colors.white70),
                                            ),
                                          ],
                                        ),

                                        const SizedBox(height: 5),

                                        Row(
                                          children: [
                                            const Icon(Icons.group,
                                                size: 16,
                                                color: Colors.white70),
                                            const SizedBox(width: 5),
                                            Text(
                                              "${event.participants} participants",
                                              style: const TextStyle(
                                                  color:
                                                      Colors.white70),
                                            ),
                                          ],
                                        ),

                                        const SizedBox(height: 5),

                                        Row(
                                          children: [
                                            const Icon(Icons.attach_money,
                                                size: 16,
                                                color: Colors.white70),
                                            const SizedBox(width: 5),
                                            Text(
                                              "${event.budget} Ar",
                                              style: const TextStyle(
                                                  color:
                                                      Colors.white70),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ),

        floatingActionButton: Container(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              colors: [
                Color(0xFFA855F7),
                Color(0xFF7C3AED),
              ],
            ),
          ),
          child: FloatingActionButton(
            onPressed: () {
            },
            backgroundColor: Colors.transparent,
            elevation: 0,
            child: const Icon(Icons.add),
          ),
        ),
      ),
    );
  }
}